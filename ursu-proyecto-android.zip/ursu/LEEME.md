# ursu me aburro 🏓

Juego de ping pong de mesa para celular (HTML5, sin librerías). Contra un oso, 3 dificultades, 2 escenarios.

## iPhone (y cualquier celular): sin instalar nada
Subí la carpeta `app/src/main/assets/www/` a cualquier hosting estático (GitHub Pages, Netlify, Cloudflare Pages).
Abrilo en Safari → Compartir → **Añadir a pantalla de inicio**. Se abre a pantalla completa y funciona sin internet.

## Android (APK)
**Opción A – sin instalar nada:** subí este proyecto a un repo de GitHub. En la pestaña *Actions* corre
"Build APK" solo; al terminar, descargá `ursu-me-aburro-apk` (adentro está `app-debug.apk`).

**Opción B – Android Studio:** abrí esta carpeta y tocá *Build ▸ Build APK(s)*.
Si ya tenés el SDK: `gradle assembleDebug` → `app/build/outputs/apk/debug/app-debug.apk`.

## Cómo se juega
Arrastrá el dedo para mover la paleta (queda arriba del dedo). Movimiento rápido = golpe fuerte (pero más riesgo de irse afuera).
Tocá la pantalla para sacar. Primero a 11, diferencia de 2.
